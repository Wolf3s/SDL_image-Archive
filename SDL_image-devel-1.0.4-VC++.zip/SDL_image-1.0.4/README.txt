
SDL_image 1.0

The full source for this package is available at:
http://www.devolution.com/~slouken/SDL/projects/SDL_image/

This is a simple library to load images of various formats as SDL surfaces.
This library currently supports BMP, PPM, PCX, GIF, JPEG, and PNG formats.

API:
#include "SDL_image.h"

	SDL_Surface *IMG_Load(const char *file);
or
	SDL_Surface *IMG_Load_RW(SDL_RWops *src, int freesrc);

An example program 'show' is included, with source in show.c

JPEG support requires the JPEG library: http://www.ijg.org/
PNG support requires the PNG library: http://www.cdrom.com/pub/png/
    and the Zlib library: http://www.cdrom.com/pub/infozip/zlib/

This library is under the GNU Library General Public License, see the file
"COPYING" for details.  Certain image loaders may be under a different
license, see the individual image loader source files for details.
